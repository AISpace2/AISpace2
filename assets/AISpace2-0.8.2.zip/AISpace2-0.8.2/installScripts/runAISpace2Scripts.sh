cd "$(dirname "$0")"
cd ..
jupyter lab