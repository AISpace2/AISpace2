This folder contains the "backend" of our extension: the Python code behind the Jupyter widget that powers our visualizations. This doesn't include the AI algorithms themselves, which are available in `aipython/`, but instead is the "glue" between those algorithms and the corresponding frontend visualizations.

The [wiki](https://github.com/AISpace2/AISpace2/wiki) contains more information if you are interested in contributing.
