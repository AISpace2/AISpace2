# Do not change this manually. Change this by runnning /updateVersion.py
version_info = (0, 8, 10)
__version__ = '.'.join(map(str, version_info))

update_notification = True
