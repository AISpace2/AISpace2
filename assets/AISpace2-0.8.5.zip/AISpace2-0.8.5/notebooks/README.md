This folder contains Jupyter notebooks that can be used alongside our extension to learn about AI concepts and view interactive visualizations.

