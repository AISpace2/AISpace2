version_info = (0, 7, 8)
__version__ = '.'.join(map(str, version_info))
