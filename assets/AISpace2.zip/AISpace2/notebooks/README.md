This folder contains Jupyter notebooks that can be used alongside our extension to learn about AI concepts and view interactive visualizations.

Note that many of the notebooks in this directory are linked on our [notebook](https://aispace2.github.io/AISpace2/notebooks.html) page, so updating them will cause users to get the newest version automatically.
