This directory contains the "frontend" of the extension - the visualizations the user sees, and also the code that communicates with the Python backend.

Head over to the [wiki](https://github.com/AISpace2/AISpace2/wiki), specifically the [Frontend Development](https://github.com/AISpace2/AISpace2/wiki/Frontend-Development) page if you are interested in development.
