This folder contains the [accompanying Python code](http://aipython.org) from the [book](http://artint.info). They are used as-is by some of the notebooks.
