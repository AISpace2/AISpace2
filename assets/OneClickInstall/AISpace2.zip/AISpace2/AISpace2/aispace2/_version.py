version_info = (0, 6, 9)
__version__ = '.'.join(map(str, version_info))
